using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct Metaball {
    public float m_weight;
    public float m_radius;
    public int m_resolution;
}
