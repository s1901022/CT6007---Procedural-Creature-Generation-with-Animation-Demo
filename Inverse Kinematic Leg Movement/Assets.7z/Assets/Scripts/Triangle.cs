using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct Triangle {
    public Vector3 triangleIndices;
}
